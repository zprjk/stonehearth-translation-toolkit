'use strict';

var path = require('path'),
  fs = require('fs-extra');

var tasks = require('../tasks/index');
var cfg = require('../tasks/config'); //json

exports.SaveGamePath = function(req, res) {
  var gamePath = req.body.gamePath;
  var file = path.resolve('./tasks/config.json');

  cfg.game.basePath = gamePath;
  tasks.ConfigFileUpdated(cfg);

  fs.outputJson(file, cfg, function(err) {
    if (err) {
      console.log(err);
      res.status(404).send(err);
    } else
      res.send(cfg.game.basePath); //200
  });
};


exports.LoadGamePath = function(req, res) {
  res.send(cfg.game.basePath);
};

exports.Generate = function(req, res) {
  var outputPath = path.join(cfg.dist.csv.basePath, cfg.dist.csv.originalFileName); // '_dist/csv/s.original.csv'

  tasks.GenerateOriginalCSV(outputPath, function(logs, err) {
    if (err) {
      console.log(err);
      res.status(404).send(logs);
    } else {
      // console.log(log);
      res.send(logs);
    }
  });
};

exports.UpdateCSV = function(req, res) {
	var dir = cfg.dist.csv.basePath;// '_dist/csv'
	console.log(dir);
  tasks.UpdateCSV(dir, function(logs, err) {
    if (err) {
      console.log(err);
      res.status(404).send(logs);
    } else {
      res.send(logs);
    }
  });
};


exports.ExportsToJson = function(req, res) {
	var dir = cfg.dist.csv.basePath;// '_dist/csv'
	console.log(dir);
  tasks.ExportsToJson(dir, function(logs, err) {
    if (err) {
      console.log(err);
      res.status(404).send(logs);
    } else {
      res.send(logs);
    }
  });
};

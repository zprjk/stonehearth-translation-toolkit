'use strict';

app.controller('indexCtrl', ['$scope', '$http', '$timeout', function($scope, $http, $timeout) {

  //INIT
  $scope.saveSucess = false;
  $scope.emptyDir = false;
  loadGamePath();

  //FUNCTIONS
  function loadGamePath() {
    $http.post('/api/loadgamepath').
    success(function(path) {
      $scope.gamePath = path;
      $scope.emptyDir = path === '' ? true : false;

    }).
    error(function(data, status) {
      console.log(data, status);
    });
  }


  $scope.SaveGamePath = function(newPath) {
    // if(newPath === '') {
    //   return;
    // }
    console.log("gamePath: " + newPath);

    $http.post('/api/savegamepath', {
      gamePath: newPath
    }).
    success(function(path, status, headers, config) {
      console.log('Game Path saved.');
      $scope.gamePath = path;
      $scope.emptyDir = path === '' ? true : false;

      $scope.saveSucess = true;
      $timeout(function() {
        $scope.saveSucess = false;
      }, 1500);
    }).
    error(function(data, status, headers, config) {
      console.log(data, status);
    });
  }
}]);
